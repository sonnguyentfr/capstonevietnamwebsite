using System.ComponentModel.DataAnnotations;

namespace NVCMS.API.ReadGoogleSheet.Models;

public class ZnsSendRequest
{
    [Required]
    public long TemplateId { get; set; }

    [Required]
    public int CampaignId { get; set; }

    public string? Phone { get; set; }

    public Dictionary<string, object?> TemplateData { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    public string? TrackingId { get; set; }
    public string? Qr { get; set; }

    public string? Type { get; set; }
    public int? EventCatId { get; set; }
    public int? EventId { get; set; }
    public string? ContextType { get; set; }
    public string? CreatedBy { get; set; }
}

public class ZnsEnqueueItemResult
{
    public long QueueId { get; set; }
    public string JobId { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string TrackingId { get; set; } = string.Empty;
}

public class ZnsEnqueueResult
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public int TotalRecipients { get; set; }
    public List<ZnsEnqueueItemResult> Items { get; set; } = [];
}

public class ZnsSendResult
{
    public bool Success { get; set; }
    public int ErrorCode { get; set; }
    public string Message { get; set; } = string.Empty;
    public string? MsgId { get; set; }
    public string? SentTime { get; set; }
    public string? SendingMode { get; set; }
    public int? RemainingQuota { get; set; }
    public int? DailyQuota { get; set; }
    public long? QueueId { get; set; }
    public string? JobId { get; set; }
}

/// <summary>
/// Tham số cho job ZnsCampaignEnqueueJob (Hangfire serialize bằng Newtonsoft,
/// nên TemplateData giữ dạng JSON string để tránh lệch kiểu giữa 2 serializer).
/// </summary>
public class ZnsCampaignEnqueueArgs
{
    public long TemplateId { get; set; }
    public int CampaignId { get; set; }
    public string TemplateDataJson { get; set; } = "{}";
    public string? TrackingId { get; set; }
    public string? Type { get; set; }
    public int? EventCatId { get; set; }
    public int? EventId { get; set; }
    public string? ContextType { get; set; }
    public string? CreatedBy { get; set; }
    /// <summary>Thời điểm gọi API — dùng để bỏ qua SĐT đã enqueue khi job retry.</summary>
    public DateTime RequestedAt { get; set; }
}

/// <summary>Body cho POST /api/zalo/send-event-job: gửi ZNS cho danh sách NV_Events_Student đã chọn.</summary>
public class ZnsEventStudentSendRequest
{
    /// <summary>Danh sách NV_Events_Student.Id</summary>
    [Required, MinLength(1)]
    public List<int> Ids { get; set; } = [];

    [Range(1, int.MaxValue)]
    public int EventId { get; set; }

    [Range(1, int.MaxValue)]
    public int EventCatId { get; set; }

    [Range(1, long.MaxValue)]
    public long TemplateId { get; set; }

    /// <summary>false (mặc định): bỏ qua SĐT đã có queue Queued/Processing/Sent cho cùng event + template.</summary>
    public bool AllowResend { get; set; }

    public string? CreatedBy { get; set; }
}

public class ZnsEventStudentSkipped
{
    public int EventStudentId { get; set; }
    public string? Phone { get; set; }
    public string Reason { get; set; } = string.Empty;
}

public class ZnsEventStudentEnqueueResult
{
    public bool Success { get; set; }
    public string Message { get; set; } = string.Empty;
    public int TotalRequested { get; set; }
    public int TotalQueued { get; set; }
    public List<ZnsEnqueueItemResult> Items { get; set; } = [];
    public List<ZnsEventStudentSkipped> Skipped { get; set; } = [];
}
